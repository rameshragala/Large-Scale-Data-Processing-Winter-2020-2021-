The Input for this program can be taken from the Sequence File Writer Program's Output
