import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class AgePartitioner extends Partitioner<Text, Text>
{
	public int getPartition(Text key, Text value, int numReduceTasks) 
	{
		String[] nameAgeScore = value.toString().split("\t");
		String age = nameAgeScore[1];
		int ageInt = Integer.parseInt(age);
		if(ageInt <=20 && ageInt > 0) 
		{
			return 0;
			}
		if (ageInt > 20 && ageInt <= 50) 
		{
			return 1;
			} 
		else 
		{
			return 2;
			}
		}
}