import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class SamplePartitioner extends Configured implements Tool 
{
	// the driver to execute two jobs and invoke the map/reduce functions
	// org.slf4j.Logger logger;
	public int run(String[] args) throws Exception 
	{
		assignPartition(args[0], args[1]);
		return 0;
		}
	
	// method to get job configuration for the customized partitioning MapReduce program
	//executing the job to run the mapper, custom partitioner and the reducer
	private void assignPartition(String inputPath, String outputPath) throws Exception 
	{
		//Job job = new Job();
		//Configuration conf = new Configuration();
		//conf.addResource(“/etc/hadoop/conf/core-site.xml”);
		//conf.addResource(“/etc/hadoop/conf/hdfs-site.xml”);
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "CustCombiner");		
		job.setMapperClass(SampleMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setPartitionerClass(AgePartitioner.class);
		job.setNumReduceTasks(3);
		job.setReducerClass(SampleReducer.class);
		job.setJarByClass(SamplePartitioner.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		job.setJobName("WordCounter");
		String input = inputPath;
		String output = outputPath;
		FileSystem fs = FileSystem.getLocal(job.getConfiguration());
		Path opPath = new Path(output);
		fs.delete(opPath, true);
		FileInputFormat.setInputPaths(job, new Path(input)); // setting
		FileOutputFormat.setOutputPath(job, new Path(output)); // setting
		job.waitForCompletion(true);
		}
	public static void main(String[] args) throws Exception 
	{
		int res = ToolRunner.run(new SamplePartitioner(), args);
		if (args.length != 2) 
		{
			System.err.println("Usage: SamplePartitioner");
			System.exit(2);
			}
		System.exit(res);
		}
	}