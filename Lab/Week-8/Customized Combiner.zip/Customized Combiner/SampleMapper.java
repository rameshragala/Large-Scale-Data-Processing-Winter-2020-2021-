import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SampleMapper extends Mapper<Object, Text, Text, Text>
{
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException 
	{
		String[] tokens = value.toString().split("\t");
		System.out.println(tokens[2]);
		String gender = tokens[2];
		String nameAgeScore = tokens[0] + "\t" + tokens[1] + "\t" + tokens[3];
		context.write(new Text(gender), new Text(nameAgeScore));
		}
	
	public void run(Context context) throws IOException, InterruptedException 
	{
		setup(context);
		while (context.nextKeyValue()) 
		{
			System.out.println(context.getCurrentKey()+ " ,  " + context.getCurrentValue());
			map(context.getCurrentKey(), context.getCurrentValue(), context);
			}
		cleanup(context);
		}
}
