import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import java.io.*;

public class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
	{
		String line = value.toString();
		String[] elements=line.split(",");
		Text tt=new Text(elements[0]);
		int i= Integer.parseInt(elements[1]);
		IntWritable it=new IntWritable(i);
		context.write(tt,it);
	}
}
