import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

class dpart extends Partitioner<Text,IntWritable>
{
public int getPartition(Text key,IntWritable value,int nr)
{
if(value.get() > 60)
	return 0;
else
	return 1;
}
}