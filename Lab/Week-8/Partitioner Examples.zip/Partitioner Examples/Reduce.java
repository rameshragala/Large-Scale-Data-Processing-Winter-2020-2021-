import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import java.io.IOException;

public class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
public void reduce(Text key, IntWritable value, Context context)
throws IOException, InterruptedException {
context.write(key, value);
}
}